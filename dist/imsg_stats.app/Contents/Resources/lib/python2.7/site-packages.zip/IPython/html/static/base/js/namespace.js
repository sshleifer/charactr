// Copyright (c) IPython Development Team.
// Distributed under the terms of the Modified BSD License.

var IPython = IPython || {};
define([], function(){
    "use strict";
    IPython.version = "3.1.0";
    IPython._target = '_blank';
    return IPython;
});
